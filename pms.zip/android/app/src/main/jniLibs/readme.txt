If your project does not call the ScanCodec module, you do not need to import
 libDCL.so,
 libIGLBarDecoder.so,
 libZBarDecoder.so,
 libiconv.so,
 libdecoder_jni.so,
 libHDSD.so,
but the 
 libDeviceConfig.so 
must import into your project.
